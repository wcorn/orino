# Changelog

- **Changed**: Update cloudflare/cloudflared image version to 2026.2.0
    - [Upstream Project](https://hub.docker.com/r/cloudflare/cloudflared)
